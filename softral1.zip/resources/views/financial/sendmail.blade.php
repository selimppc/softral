@extends('laravel-authentication-acl::admin.layouts.base-2cols')

@section('title')
Admin area: Send Mail to Users
@stop

@section('content')

<div class="row">
    <div class="col-md-12">
        <?php $message = Session::get('message'); ?>
        @if( isset($message) )
        <div class="alert alert-success">{!! $message !!}</div>
        @endif
		
		<?php $error = Session::get('error'); ?>
        @if( isset($error) )
        <div class="alert alert-danger">{!! $error !!}</div>
        @endif
       @if($errors->any())
			<div class="alert alert-danger">
				@foreach($errors->all() as $error)
					<p>{{ $error }}</p>
				@endforeach
			</div>
		@endif
        <div class="panel panel-info">
            <div class="panel-heading">
                <div class="row">
                    <div class="col-md-12">
                        <h3 class="panel-title bariol-thin"><i class="fa fa-send"></i> Send Mail</h3>
                    </div>
                </div>
            </div>
            <div class="panel-body">
                <div class="row">
                    
					<div class="col-md-12 col-xs-12">
                
					{!! Form::open(array('route' => 'mailSend', 'class' => 'form','method' => 'POST')) !!}
				
				<div class="form-group">
				
				<div class='row'>
					<div class='col-md-6'>
				{!! Form::label('users', 'Users', ['class' => 'control-label','style'=>'display:block']) !!}
				{!! Form::select('users',$users,null,array('multiple'=>'multiple','name'=>'users[]')) !!}
				</div>
					</div>
					
					<div class='row'>
					<div class='col-md-6'>
					{!! Form::label('Messages', 'Messages: *', ['class' => 'control-label','style'=>'display:block']) !!}
				<textarea rows="10" cols="50" name="message" required></textarea>
					</div>
					</div>
				</div>
				<a href="{!! URL::route('financial') !!}" class='btn btn-primary'>Back</a>
				 
				{!! Form::submit('Submit', ['class' => 'btn btn-primary']) !!}
				
				{!! Form::close() !!}
                    </div>
                </div>
                <div class="row">
                   
            </div>
        </div>
    </div>
</div>
 {!! HTML::script('packages/jacopo/laravel-authentication-acl/js/vendor/jquery-1.10.2.min.js') !!}
  <script>
      
	$(function() {
         $(".delete_account").click(function(){
            return confirm("Are you sure to delete this item?");
        });
		
    });
	
    </script>
@stop
