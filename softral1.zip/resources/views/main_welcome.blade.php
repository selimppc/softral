@extends('laravel-authentication-acl::client.layouts.base-fullscreen')
@section('title')
Softral - Welcome to Softral
@stop
@section('content')

<div class="container">
	<div class="gallary">
    	<div class="row">
        	<div class="col-lg-8 col-md-8 col-sm-12 col-xs-12">
                <div class="hexa-section">
                	<div class="honeycombs">
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span>
                        </div>
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span>
                        </div>
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span>
                        </div>
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span> 
                        </div>
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span>
                        </div>
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span> 
                        </div>
                        <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span> 
                        </div>
                         <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span> 
                        </div>
                         <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span> 
                        </div>
                         <div class="comb"> 
                            <img src="../public/images/img2.jpg" />
                            <span>Image Caption 1</span> 
                        </div>              	
                	</div>
                	<ul id="categories" class="clr">
                      <li class="pusher"></li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                        <li class="pusher"></li>
                        <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                        <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                        <li class="pusher"></li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                      <li>
                          <div>
                            <img src="../public/images/img2.jpg" alt=""/>
                            <h1>This is a title a bit longer</h1>
                            <p>Some sample text about the article this hexagon leads to</p>
                        </div>
                      </li>
                    </ul>
               	</div>
           	</div>
            <div class="col-lg-4 col-md-4 col-sm-12 col-xs-12">
            	<div class="news-section">
                	<div class="news">
                	<h3>Employee News</h3>
                    <marquee direction="up" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="2">
                    	<a href="#">News 1 Lorem Ipsum.</a>
                        <a href="#">News 2 Lorem Ipsum Dollor amet to click to gethor.</a>
                        <a href="#">News 3 Lorem Ipsum.</a>
                        <a href="#">News 4 Lorem Ipsum Dollor amet to click to gethor.</a>
                        <a href="#">News 5 Lorem Ipsum.</a>
                        <a href="#">News 6 Lorem Ipsum Dollor amet to click to gethor.</a>
                    </marquee>                    
                </div>
                	<div class="news">
                	<h3>Freelancer News</h3>
                    <marquee direction="up" onmouseover="this.stop();" onmouseout="this.start();" scrollamount="2">
                    	<a href="#">News 1 Lorem Ipsum.</a>
                        <a href="#">News 2 Lorem Ipsum Dollor amet to click to gethor.</a>
                        <a href="#">News 3 Lorem Ipsum.</a>
                        <a href="#">News 4 Lorem Ipsum Dollor amet to click to gethor.</a>
                        <a href="#">News 5 Lorem Ipsum.</a>
                        <a href="#">News 6 Lorem Ipsum Dollor amet to click to gethor.</a>
                    </marquee>                    
                </div>
                </div>
            </div>
        </div>
    </div>
  	  <div class="dummy_text">
    	<h1>About Us</h1>
    	
        	{!!$about['content'] !!}
        
    </div>


@stop